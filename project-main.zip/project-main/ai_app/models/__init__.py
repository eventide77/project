# models/__init__.py
from .ImageElement import ImageElement
from .TitleElement import TextElement
from .BookModel import Book
